let questions = [
    {
        numb: 1,
        question: "Ok! Here's an easy one to start off with. What do you have to do with Pokemon?",
        answer: "3. Catch 'em all!",
        options: [
           "1. Snatch 'em all!",
           "2. Fetch 'em all!",
           "3. Catch 'em all!",
           "4. Hit like and subscribe"

        ]

    },
    {
        numb: 2,
        question: "Sophie is a character from which anime movie?",
        answer: "3. Howl's Moving Castle",
        options: [
            "1. Go! Princess PreCure",
            "2. Snow White with The Red Hair",
            "3. Howl's Moving Castle",
            "4. Sailor Moon"

        ]

    },
    {
        numb: 3,
        question: "In Dragon Ball Super, Goku is sent to destroy earth. What happened to make him change his ways?",
        answer: "2. He bumped his head",
        options: [
            "1. He just realised it was quite mean",
            "2. He bumped his head",
            "3. He couldn't be bothered in the end",
            "4. No-one knows"

        ]

    },
    {
        numb: 4,
        question: "Which pirate once owned One Piece??",
        answer: "4. Gol D. Roger",
        options: [
            "1. Buggy",
            "2. Foxy",
            "3. Portgas D. Ace",
            "4. Gol D. Roger"

        ]

    },
    {
        numb: 5,
        question: "How do you do a Naruto run?",
        answer: "1. Put your head forward and arms back",
        options: [
            "1. Put your head forward and arms back",
            "2. Put your left foot in, your left foot out",
            "3. You do the hokey cokey and your turn around",
            "4. That's what it's all about"

        ]

        

    },
    {
        numb: 6,
        question: "Fill in the blank...Dragon ___ Z",
        answer: "2. Ball",
        options: [
            "1. Beach",
            "2. Ball",
            "3. Mech",
            "4. Film"

        ]

    },
    {
        numb: 7,
        question: "How old is Chihiro in Spirited Away?",
        answer: "2. 10",
        options: [
            "1. 7",
            "2. 10",
            "3. 13",
            "4. 16"

        ]

    },
    {
        numb: 8,
        question: "What percentage of the world's animation is anime?",
        answer: "4. 60%",
        options: [
            "1. 20%",
            "2. 35%",
            "3. 50%",
            "4. 60%"

        ]

    },
    {
        numb: 9,
        question: "What movie was not animated by Studio Ghibli?",
        answer: "3. Your Name",
        options: [
            "1. Princess Mononoke",
            "2. Kiki's Delivery Service",
            "3. Your Name",
            "4. Only Yesterday"

        ]

    },
    {
        numb: 10,
        question: "What is the highest grossing anime movie of all time?",
        answer: "1. Demon Slayer the Movie: Mugen Train",
        options: [
            "1. Demon Slayer the Movie: Mugen Train",
            "2. Weathering with You",
            "3. Ponyo",
            "4. Pokemon: the first movie"

        ]

    }
    
    
]